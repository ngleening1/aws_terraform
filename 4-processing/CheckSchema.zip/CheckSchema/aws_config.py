REGION = "ap-southeast-1"

SCHEMA_BUCKET_NAME = "your-schema-bucket"
ARCHIVE_BUCKET_NAME = "your-archival-bucket"

NOTIFY_ERROR_ARN = "sns-error-arn"
NOTIFY_INFO_ARN = "sns-info-arn"
