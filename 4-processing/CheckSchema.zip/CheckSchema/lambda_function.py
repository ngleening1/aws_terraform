import datetime as dt
import json
import logging
import os
import urllib.parse

import boto3
import numpy as np
import pandas
import pytz
from . import aws_config

REGION_NAME = os.getenv("REGION_NAME", aws_config.REGION)

SCHEMA_BUCKET_NAME = os.getenv("SCHEMA_BUCKET_NAME", aws_config.SCHEMA_BUCKET_NAME)  # noqa: E501
ARCHIVE_BUCKET_NAME = os.getenv("ARCHIVE_BUCKET_NAME", aws_config.ARCHIVE_BUCKET_NAME)  # noqa: E501

SNS_MAX_MESSAGE_LEN = int(os.getenv("SNS_MESSAGE_LEN", "4096"))
NOTIFY_ERROR_ARN = os.getenv("NOTIFY_ERROR_ARN", aws_config.NOTIFY_ERROR_ARN)
NOTIFY_INFO_ARN = os.getenv("NOTIFY_INFO_ARN", aws_config.NOTIFY_INFO_ARN)

CHUNK_SIZE = os.getenv("CHUNKSIZE", "1500")

s3 = boto3.client("s3", region_name=REGION_NAME)
sns = boto3.client("sns", region_name=REGION_NAME)

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def get_key_schema_name(event):
    """
    Gets the S3 object key and schema name from the filepath.

    Args:
        event (dict): Lambda event values from S3.

    Returns:
        (str, str): Returns the schema name and returns the rest of the S3 object key.  # noqa: E501
    """
    _, key = get_bucket_key_from_event(event)
    toks = key.split("/")
    restOfKey = "/".join(toks[1:])  # handle for if key name also has "/"
    logger.info(
        "Parsing schemaName: ({schemaName}) dataKey: ({dataKey})".format(
            schemaName=toks[0], dataKey=restOfKey
        )
    )
    return toks[0], restOfKey


def get_schema(name):
    """
    Get data schema from the name of the data source. E.g. admin_demographics.

    Args:
        name (str): Name of the data source.

    Returns:
        dict: Schema in the form of a dict.
    """
    obj = name + ".json"
    obj = s3.get_object(Bucket=SCHEMA_BUCKET_NAME, Key=obj)
    fileContent = obj["Body"].read().decode("utf-8")
    schema = json.loads(fileContent)
    # lower all values in dict
    schema = {k.lower(): v.lower() for k, v in schema.items()}

    logger.info("Get Schema: {schema}".format(schema=schema))
    return schema


def archive_data(event):
    """
    Archives data that has already been processed onto an archive bucket in S3.
    Archived data are in the form of `<schemaName>_<timestamp>_<originalfilekey>`.  # noqa: E501
    Timestamp has been localised to the Singapore timezone for easy reference.

    Args:
        event (dict): Lambda event values from S3.
    """
    origBucket, origKey = get_bucket_key_from_event(event)
    schemaName, dataKey = get_key_schema_name(event)
    archiveKey = "{schemaName}/{timestamp}_{dataKey}".format(
        schemaName=schemaName,
        timestamp=dt.datetime.now(pytz.timezone("Asia/Singapore")),
        dataKey=dataKey,
    )
    copySource = {"Bucket": origBucket, "Key": origKey}
    s3.copy(copySource, ARCHIVE_BUCKET_NAME, archiveKey)
    logger.info(
        "Archiving to (%s) with copy source (%s)" % (ARCHIVE_BUCKET_NAME, copySource)  # noqa: E501
    )


def cleanup_storage(event):
    """
    Cleans up the ingested file from S3 storage.

    Args:
        event (str): Lambda event for S3.
    """
    bucket, key = get_bucket_key_from_event(event)
    s3.delete_object(Bucket=bucket, Key=key)
    logger.info("Deleting from bucket:(%s) key:(%s)" % (bucket, key))


def validate_df(schema, df):
    """
    Validate dataframe using schema.
    Validation include:
      * columns of DF must be the same as schema fields
      * column names must correspond to a schema field

    Args:
        schema (dict): Schema of that the datasources provides.
        df (pandas.DataFrame): Dataframe to be validated.

    Returns:
        boolean: Returns true if dataframe follows the schema.
    """
    # check the length of column vs schema
    if len(df.columns) != len(schema):
        return False

    # tolower() all of the columns for convention
    df.columns = map(str.lower, df.columns)

    # check each column name is same as schema names
    schemaCols = {col.lower() for col in schema.keys()}
    for key in df.columns:
        if key not in schemaCols:
            return False

    return True


def get_bucket_key_from_event(event):
    """
    Gets the bucket and key from the event dict populated by S3 trigger.

    Args:
        event (dict): Lambda event values from S3.

    Returns:
        (str, str): Returns bucket and key from the S3 event record.
    """
    bucket = event["Records"][0]["s3"]["bucket"]["name"]
    key = urllib.parse.unquote_plus(
        event["Records"][0]["s3"]["object"]["key"], encoding="utf-8"
    )
    return bucket, key


def translate_schema_dtype(val):
    """
    Changes the schema datatype to pandas acceptable datatype.
    This is done to enforce stricter data typing during ingestion.

    Raises:
        Exception: If the data type is not allowed in the vision data types.

    Returns:
        str: Returns the translated pandas data type.
    """
    if val == "str":
        return np.dtype(str)
    elif val == "int":
        return "Int64"
    elif val == "float":
        return np.dtype(float)
    elif val == "bool":
        return "boolean"
    elif val == "datetime64":
        return np.dtype(str)
    raise ValueError(
        "Unable to translate with invalid dtype ({dType})".format(dType=val)
    )


def extract_csv_options(event, schema):
    """
    Gets options required to read csv using pandas.

    Args:
        event (dict): Lambda event values from S3.
        schema (dict): Schema json to be translated to pandas dtype.

    Returns:
        (S3StreamingObject, dict): Returns ingestion S3 file to be read by
        pandas and with the schema dtype.
    """
    bucket, key = get_bucket_key_from_event(event)
    obj = s3.get_object(Bucket=bucket, Key=key)
    dtypes = {k: translate_schema_dtype(v) for k, v in schema.items()}
    return obj, dtypes


def notify_sns(arn, title, e):
    """
    Publishes messages on SNS.

    Args:
        arn (str): SNS arn to publish to.
        title (str): Title of SNS message.
        e (Exception): The exception to be published.
    """
    msg = str(e)
    msg = msg if len(msg) < SNS_MAX_MESSAGE_LEN else msg[:SNS_MAX_MESSAGE_LEN] + " ..."  # noqa: E501
    sns.publish(TopicArn=arn, Subject=title, Message=msg)
    logger.info("Notified sns ARN:(%s)" % (arn))


def handle_error(e):
    """
    Handles on error. For now this just logs to the Lambda log group.

    Args:
        e (Exception): The exception to be handled.
    """
    logger.error("Unexpected error")
    logger.exception(e)


def lambda_handler(event, context):
    """
    This function is the controller that handles data ingestion
    """

    try:
        # 1. Read schema from object path
        schemaName, dataKey = get_key_schema_name(event)
        schema = get_schema(schemaName)

        # 1.1 Validate object has data
        if int(event["Records"][0]["s3"]["object"]["size"]) == 0:
            if len(dataKey) > 0:
                archive_data(event)
                cleanup_storage(event)
                bucket, objKey = get_bucket_key_from_event(event)
                raise Exception(
                    "Deleting Object ({bucket}/{key} because it has no data!".format(  # noqa: E501
                        bucket=bucket, key=objKey
                    )
                )
            else:
                return

        # 2. Extract options required to parse csv as a chunk
            obj, dtypes = extract_csv_options(event, schema)
            for chunk in pandas.read_csv(
                obj["Body"], sep=",", dtype=dtypes, chunksize=int(CHUNK_SIZE),
            ):
                # 3. Check validity
                if validate_df(schema, chunk) is False:
                    raise Exception(
                        "Difference between df and schema: want column len (%d) got column len (%d) want types (%s) got types (%s)"  # noqa: E501
                        % (len(schema), len(chunk.columns), schema, chunk.dtypes)  # noqa: E501
                    )

        # 4. Archive data
        archive_data(event)

        # 5. Remove data from upload folder
        cleanup_storage(event)

        bucket, key = get_bucket_key_from_event(event)
        finishedMsg = "Completed data ingestion of bucket: ({bucket}) key: ({key})".format(  # noqa: E501
            bucket=bucket, key=key
        )
        notify_sns(NOTIFY_INFO_ARN, "Data upload info", finishedMsg)
        logger.info("Completed upload of object key:(%s/%s)!" % (schemaName, dataKey))  # noqa: E501
    except Exception as e:
        bucket, objKey = get_bucket_key_from_event(event)
        errMsg = "Error on ingesting object key: ({objKey}) in bucket ({bucket}): {reason}".format(  # noqa: E501
            objKey=objKey, bucket=bucket, reason=str(e)
        )
        notify_sns(NOTIFY_ERROR_ARN, "Data upload error", errMsg)
        handle_error(e)
